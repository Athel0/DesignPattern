/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYPIZZAINGREDIENTFACTORY_H
#define NYPIZZAINGREDIENTFACTORY_H

#include "IPizzaIngredientFactory.h"

class NYPizzaIngredientFactory : public IPizzaIngredientFactory
{
public:
    NYPizzaIngredientFactory();
    virtual ~NYPizzaIngredientFactory();

    IDough *CreateDough();
    ISauce *CreateSauce();
    ICheese *CreateCheese();
    list<IVeggies*> CreateVeggies();
    IPepperoni *CreatePepperoni();
    IClam *CreateClam();
};

#endif // NYPIZZAINGREDIENTFACTORY_H
