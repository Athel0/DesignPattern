#ifndef ICLAM_H
#define ICLAM_H

#include <iostream>
using namespace std;

class IClam
{
public:
    IClam()
    {
    }
    virtual ~IClam()
    {
    }

    virtual string ToString() = 0;
};

#endif // ICLAM_H
