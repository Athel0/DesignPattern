/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "BlackOlives.h"

BlackOlives::BlackOlives()
{
}

BlackOlives::~BlackOlives()
{
}

string BlackOlives::ToString()
{
    return "Black Olives";
}
