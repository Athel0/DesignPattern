/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef MOZZARELLACHEESE_H
#define MOZZARELLACHEESE_H

#include "ICheese.h"

class MozzarellaCheese : public ICheese
{
public:
    MozzarellaCheese();
    virtual ~MozzarellaCheese();

    string ToString();
};

#endif // MOZZARELLACHEESE_H
