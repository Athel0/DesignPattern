/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ClamPizza.h"

ClamPizza::ClamPizza(IPizzaIngredientFactory *ingredientFactory)
{
    m_ingredientFactory = ingredientFactory;
}

ClamPizza::~ClamPizza()
{
}

void ClamPizza::Prepare()
{
    cout << "Preparing " << m_name << endl;
    m_dough = m_ingredientFactory->CreateDough();
    m_sauce = m_ingredientFactory->CreateSauce();
    m_cheese = m_ingredientFactory->CreateCheese();
    m_clam = m_ingredientFactory->CreateClam();
}
