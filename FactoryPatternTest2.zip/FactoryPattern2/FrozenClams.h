/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef FROZENCLAMS_H
#define FROZENCLAMS_H

#include "IClam.h"

class FrozenClams : public IClam
{
public:
    FrozenClams();
    virtual ~FrozenClams();

    string ToString();
};

#endif // FROZENCLAMS_H
