/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CLAMPIZZA_H
#define CLAMPIZZA_H

#include "Pizza.h"
#include "IPizzaIngredientFactory.h"

class ClamPizza : public Pizza
{
public:
    ClamPizza(IPizzaIngredientFactory *ingrediendFactory);
    virtual ~ClamPizza();

    void Prepare();

private:
    IPizzaIngredientFactory *m_ingredientFactory;
};

#endif // CLAMPIZZA_H
