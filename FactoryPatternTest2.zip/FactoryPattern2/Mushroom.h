/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef MUSHROOM_H
#define MUSHROOM_H

#include "IVeggies.h"

class Mushroom : public IVeggies
{
public:
    Mushroom();
    virtual ~Mushroom();

    string ToString();
};

#endif // MUSHROOM_H
