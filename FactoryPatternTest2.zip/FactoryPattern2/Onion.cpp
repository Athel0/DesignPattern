/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Onion.h"

Onion::Onion()
{
}

Onion::~Onion()
{
}

string Onion::ToString()
{
    return "Onion";
}
