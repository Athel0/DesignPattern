/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Garlic.h"

Garlic::Garlic()
{
}

Garlic::~Garlic()
{
}

string Garlic::ToString()
{
    return "Garlic";
}
