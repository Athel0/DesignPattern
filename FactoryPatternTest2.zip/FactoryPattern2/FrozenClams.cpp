/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "FrozenClams.h"

FrozenClams::FrozenClams()
{
}

FrozenClams::~FrozenClams()
{
}

string FrozenClams::ToString()
{
    return "Frozen Clams from Chesapeake Bay";
}
