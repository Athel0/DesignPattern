/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "SlicedPepperoni.h"

SlicedPepperoni::SlicedPepperoni()
{
}

SlicedPepperoni::~SlicedPepperoni()
{
}

string SlicedPepperoni::ToString()
{
    return "Sliced Pepperoni";
}
