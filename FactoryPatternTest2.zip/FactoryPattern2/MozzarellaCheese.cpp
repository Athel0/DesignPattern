/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "MozzarellaCheese.h"

MozzarellaCheese::MozzarellaCheese()
{
}

MozzarellaCheese::~MozzarellaCheese()
{
}

string MozzarellaCheese::ToString()
{
    return "Shredded Mozzarella";
}
