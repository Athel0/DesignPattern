/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef PLUMTOMATOSAUCE_H
#define PLUMTOMATOSAUCE_H

#include "ISauce.h"

class PlumTomatoSauce : public ISauce
{
public:
    PlumTomatoSauce();
    virtual ~PlumTomatoSauce();

    string ToString();
};

#endif // PLUMTOMATOSAUCE_H
