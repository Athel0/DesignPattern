/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ReggianoCheese.h"

ReggianoCheese::ReggianoCheese()
{
}

ReggianoCheese::~ReggianoCheese()
{
}

string ReggianoCheese::ToString()
{
    return "Reggiano Cheese";
}
