#ifndef IPEPPERONI_H
#define IPEPPERONI_H

#include <iostream>
using namespace std;

class IPepperoni
{
public:
    IPepperoni()
    {
    }
    virtual ~IPepperoni()
    {
    }

    virtual string ToString() = 0;
};

#endif // IPEPPERONI_H
