/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef BLACKOLIVES_H
#define BLACKOLIVES_H

#include "IVeggies.h"

class BlackOlives : public IVeggies
{
public:
    BlackOlives();
    virtual ~BlackOlives();

    string ToString();
};

#endif // BLACKOLIVES_H
