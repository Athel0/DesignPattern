/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "PepperoniPizza.h"

PepperoniPizza::PepperoniPizza(IPizzaIngredientFactory *ingredientFactory)
{
    m_ingredientFactory = ingredientFactory;
}

PepperoniPizza::~PepperoniPizza()
{
}

void PepperoniPizza::Prepare()
{
    cout << "Prepaing " << m_name << endl;
    m_dough = m_ingredientFactory->CreateDough();
    m_sauce = m_ingredientFactory->CreateSauce();
    m_cheese = m_ingredientFactory->CreateCheese();
    m_veggiesList = m_ingredientFactory->CreateVeggies();
    m_pepperoni = m_ingredientFactory->CreatePepperoni();
}
