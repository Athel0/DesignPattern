/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef VEGGIEPIZZA_H
#define VEGGIEPIZZA_H

#include "Pizza.h"
#include "IPizzaIngredientFactory.h"

class VeggiePizza : public Pizza
{
public:
    VeggiePizza(IPizzaIngredientFactory *ingredientFactory);
    virtual ~VeggiePizza();

    void Prepare();

private:
    IPizzaIngredientFactory *m_ingredientFactory;
};

#endif // VEGGIEPIZZA_H
