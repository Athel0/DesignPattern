/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "FreshClams.h"

FreshClams::FreshClams()
{
}

FreshClams::~FreshClams()
{
}

string FreshClams::ToString()
{
    return "Fresh Clams from Long Island Sound";
}
