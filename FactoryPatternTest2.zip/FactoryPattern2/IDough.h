#ifndef IDOUGH_H
#define IDOUGH_H

#include <iostream>
using namespace std;

class IDough
{
public:
    IDough()
    {
    }
    virtual ~IDough()
    {
    }

    virtual string ToString() = 0;
};

#endif // IDOUGH_H

