/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Mushroom.h"

Mushroom::Mushroom()
{
}

Mushroom::~Mushroom()
{
}

string Mushroom::ToString()
{
    return "Mushrooms";
}
