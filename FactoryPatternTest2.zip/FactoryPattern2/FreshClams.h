/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef FRESHCLAMS_H
#define FRESHCLAMS_H

#include "IClam.h"

class FreshClams : public IClam
{
public:
    FreshClams();
    virtual ~FreshClams();

    string ToString();
};

#endif // FRESHCLAMS_H
