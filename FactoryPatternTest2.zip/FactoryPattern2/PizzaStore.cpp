/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "PizzaStore.h"

PizzaStore::PizzaStore()
{
}

PizzaStore::~PizzaStore()
{
}

Pizza *PizzaStore::OrderPizza(string type)
{
    Pizza *pizza = CreatePizza(type);
    cout << "--- Making a " << pizza->GetName() << " ---" << endl;
    pizza->Prepare();
    pizza->Bake();
    pizza->Cut();
    pizza->Box();
    return pizza;
}
