#ifndef ISAUCE_H
#define ISAUCE_H

#include <iostream>
using namespace std;

class ISauce
{
public:
    ISauce()
    {
    }
    virtual ~ISauce()
    {
    }

    virtual string ToString() = 0;
};

#endif // ISAUCE_H
