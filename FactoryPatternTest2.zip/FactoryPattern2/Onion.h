/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef ONION_H
#define ONION_H

#include "IVeggies.h"

class Onion : public IVeggies
{
public:
    Onion();
    virtual ~Onion();

    string ToString();
};

#endif // ONION_H
