/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef SLICEDPEPPERONI_H
#define SLICEDPEPPERONI_H

#include "IPepperoni.h"

class SlicedPepperoni : public IPepperoni
{
public:
    SlicedPepperoni();
    virtual ~SlicedPepperoni();

    string ToString();
};

#endif // SLICEDPEPPERONI_H
