#include <sstream>
#include "Pizza.h"

Pizza::Pizza()
    : m_dough(NULL)
    , m_sauce(NULL)
    , m_cheese(NULL)
    , m_pepperoni(NULL)
    , m_clam(NULL)
{
}

Pizza::~Pizza()
{
}

void Pizza::Bake()
{
    cout << "Bake for 25 minutes at 350" << endl;
}

void Pizza::Cut()
{
    cout << "Cutting the pizza into diagonal slices" << endl;
}

void Pizza::Box()
{
    cout << "Place pizza in official PizzaStore box" << endl;
}

void Pizza::SetName(string name)
{
    m_name = name;
}

string Pizza::GetName()
{
    return m_name;
}

string Pizza::ToString()
{
    stringstream result;
    result << "---- " << m_name << " ----" << endl;

    if(NULL != m_dough){
        result << m_dough->ToString() << endl;
    }

    if(NULL != m_sauce){
        result << m_sauce->ToString() << endl;
    }

    if(NULL != m_cheese){
        result << m_cheese->ToString() << endl;
    }

    if(m_veggiesList.size() > 0){
        list<IVeggies*>::iterator it = m_veggiesList.begin();

        while(it != m_veggiesList.end()){
            result << (*it)->ToString();
            it++;

            if(it != m_veggiesList.end()){
                result << ", ";
            }
        }
        result << endl;
    }

    if(NULL != m_pepperoni){
        result << m_pepperoni->ToString() << endl;
    }

    if(NULL != m_clam){
        result << m_clam->ToString() << endl;
    }

    return result.str();
}
