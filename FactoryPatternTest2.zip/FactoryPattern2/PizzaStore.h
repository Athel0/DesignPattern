/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef PIZZASTORE_H
#define PIZZASTORE_H

#include <iostream>
#include "Pizza.h"

using namespace std;

class PizzaStore
{
public:
    PizzaStore();
    virtual ~PizzaStore();

    virtual Pizza *CreatePizza(string type) = 0;
    Pizza *OrderPizza(string type);
};

#endif // PIZZASTORE_H
