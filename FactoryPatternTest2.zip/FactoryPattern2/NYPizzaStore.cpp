/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYPizzaStore.h"
#include "NYPizzaIngredientFactory.h"
#include "CheesePizza.h"
#include "VeggiePizza.h"
#include "PepperoniPizza.h"
#include "ClamPizza.h"
#include "CommonDefine.h"

NYPizzaStore::NYPizzaStore()
{
}

NYPizzaStore::~NYPizzaStore()
{
}

Pizza *NYPizzaStore::CreatePizza(string type)
{
    Pizza *pizza = NULL;
    IPizzaIngredientFactory *ingredientFactory = new NYPizzaIngredientFactory();

    if(0 == type.compare(STR_TYPE_CHEESE)){
        pizza = new CheesePizza(ingredientFactory);
        pizza->SetName("New York Style Cheese Pizza");
    }
    else if(0 == type.compare(STR_TYPE_VEGGIE)){
        pizza = new VeggiePizza(ingredientFactory);
        pizza->SetName("New York Style Veggie Pizza");
    }
    else if(0 == type.compare(STR_TYPE_PEPPERONI)){
        pizza = new PepperoniPizza(ingredientFactory);
        pizza->SetName("New York Style Pepperoni Pizza");
    }
    else if(0 == type.compare(STR_TYPE_CLAM)){
        pizza = new ClamPizza(ingredientFactory);
        pizza->SetName("New York Style Clam Pizza");
    }

    return pizza;
}
