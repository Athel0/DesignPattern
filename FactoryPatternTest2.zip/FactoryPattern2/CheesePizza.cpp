/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "CheesePizza.h"

CheesePizza::CheesePizza(IPizzaIngredientFactory *ingredientFactory)
{
    m_ingredientFactory = ingredientFactory;
}

CheesePizza::~CheesePizza()
{
}

void CheesePizza::Prepare()
{
    cout << "Preparing " << m_name << endl;
    m_dough = m_ingredientFactory->CreateDough();
    m_sauce = m_ingredientFactory->CreateSauce();
    m_cheese = m_ingredientFactory->CreateCheese();
}
