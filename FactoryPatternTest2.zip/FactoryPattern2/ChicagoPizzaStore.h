/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOPIZZASTORE_H
#define CHICAGOPIZZASTORE_H

#include "PizzaStore.h"

class ChicagoPizzaStore : public PizzaStore
{
public:
    ChicagoPizzaStore();
    virtual ~ChicagoPizzaStore();

    Pizza *CreatePizza(string type);
};

#endif // CHICAGOPIZZASTORE_H
