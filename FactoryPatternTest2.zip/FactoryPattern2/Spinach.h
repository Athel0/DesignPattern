/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef SPINACH_H
#define SPINACH_H

#include "IVeggies.h"

class Spinach : public IVeggies
{
public:
    Spinach();
    virtual ~Spinach();

    string ToString();
};

#endif // SPINACH_H
