/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef PEPPERONIPIZZA_H
#define PEPPERONIPIZZA_H

#include "Pizza.h"
#include "IPizzaIngredientFactory.h"

class PepperoniPizza : public Pizza
{
public:
    PepperoniPizza(IPizzaIngredientFactory *ingredientFactory);
    virtual ~PepperoniPizza();

    void Prepare();

private:
    IPizzaIngredientFactory *m_ingredientFactory;
};

#endif // PEPPERONIPIZZA_H
