/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef THICKCRUSTDOUGH_H
#define THICKCRUSTDOUGH_H

#include "IDough.h"

class ThickCrustDough : public IDough
{
public:
    ThickCrustDough();
    virtual ~ThickCrustDough();

    string ToString();
};

#endif // THICKCRUSTDOUGH_H
