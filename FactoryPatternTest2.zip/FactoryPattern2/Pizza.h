#ifndef PIZZA_H
#define PIZZA_H

#include <iostream>
#include <list>

#include "IDough.h"
#include "ISauce.h"
#include "ICheese.h"
#include "IVeggies.h"
#include "IPepperoni.h"
#include "IClam.h"

using namespace std;

class Pizza
{
public:
    Pizza();
    virtual ~Pizza();

    virtual void Prepare() = 0;
    void Bake();
    void Cut();
    void Box();
    void SetName(string name);
    string GetName();
    string ToString();

protected:
    string m_name;
    IDough *m_dough;
    ISauce *m_sauce;
    ICheese *m_cheese;
    list<IVeggies*> m_veggiesList;
    IPepperoni *m_pepperoni;
    IClam *m_clam;
};

#endif // PIZZA_H
