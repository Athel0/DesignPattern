/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHEESEPIZZA_H
#define CHEESEPIZZA_H

#include "Pizza.h"
#include "IPizzaIngredientFactory.h"

class CheesePizza : public Pizza
{
public:
    CheesePizza(IPizzaIngredientFactory *ingredientFactory);
    virtual ~CheesePizza();

    void Prepare();

private:
    IPizzaIngredientFactory *m_ingredientFactory;
};

#endif // CHEESEPIZZA_H
