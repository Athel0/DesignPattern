/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYPIZZASTORE_H
#define NYPIZZASTORE_H

#include "PizzaStore.h"

class NYPizzaStore : public PizzaStore
{
public:
    NYPizzaStore();
    virtual ~NYPizzaStore();

    Pizza *CreatePizza(string type);
};

#endif // NYPIZZASTORE_H
