/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYPizzaIngredientFactory.h"
#include "ThinCrustDough.h"
#include "MarinaraSauce.h"
#include "ReggianoCheese.h"
#include "Garlic.h"
#include "Onion.h"
#include "Mushroom.h"
#include "RedPepper.h"
#include "SlicedPepperoni.h"
#include "FreshClams.h"

NYPizzaIngredientFactory::NYPizzaIngredientFactory()
{
}

NYPizzaIngredientFactory::~NYPizzaIngredientFactory()
{
}

IDough *NYPizzaIngredientFactory::CreateDough()
{
    return new ThinCrustDough();
}

ISauce *NYPizzaIngredientFactory::CreateSauce()
{
    return new MarinaraSauce();
}

ICheese *NYPizzaIngredientFactory::CreateCheese()
{
    return new ReggianoCheese();
}

list<IVeggies*> NYPizzaIngredientFactory::CreateVeggies()
{
    list<IVeggies*> veggiesList;
    veggiesList.push_back(new Garlic());
    veggiesList.push_back(new Onion());
    veggiesList.push_back(new Mushroom());
    veggiesList.push_back(new RedPepper());
    return veggiesList;
}

IPepperoni *NYPizzaIngredientFactory::CreatePepperoni()
{
    return new SlicedPepperoni();
}

IClam *NYPizzaIngredientFactory::CreateClam()
{
    return new FreshClams();
}
