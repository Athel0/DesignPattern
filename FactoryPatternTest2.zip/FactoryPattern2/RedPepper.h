/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef REDPEPPER_H
#define REDPEPPER_H

#include "IVeggies.h"

class RedPepper : public IVeggies
{
public:
    RedPepper();
    virtual ~RedPepper();

    string ToString();
};

#endif // REDPEPPER_H
