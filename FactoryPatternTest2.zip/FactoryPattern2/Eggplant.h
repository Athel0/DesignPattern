/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef EGGPLANT_H
#define EGGPLANT_H

#include "IVeggies.h"

class Eggplant : public IVeggies
{
public:
    Eggplant();
    virtual ~Eggplant();

    string ToString();
};

#endif // EGGPLANT_H
