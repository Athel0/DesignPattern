#ifndef IPIZZAINGREDIENTFACTORY_H
#define IPIZZAINGREDIENTFACTORY_H

#include <list>
#include "IDough.h"
#include "ISauce.h"
#include "ICheese.h"
#include "IVeggies.h"
#include "IPepperoni.h"
#include "IClam.h"

class IPizzaIngredientFactory
{
public:
    IPizzaIngredientFactory()
    {
    }
    virtual ~IPizzaIngredientFactory()
    {
    }

    virtual IDough *CreateDough() = 0;
    virtual ISauce *CreateSauce() = 0;
    virtual ICheese *CreateCheese() = 0;
    virtual list<IVeggies*> CreateVeggies() = 0;
    virtual IPepperoni *CreatePepperoni() = 0;
    virtual IClam *CreateClam() = 0;
};

#endif // IPIZZAINGREDIENTFACTORY_H
