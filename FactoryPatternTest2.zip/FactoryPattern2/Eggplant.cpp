/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Eggplant.h"

Eggplant::Eggplant()
{
}

Eggplant::~Eggplant()
{
}

string Eggplant::ToString()
{
    return "Eggplant";
}
