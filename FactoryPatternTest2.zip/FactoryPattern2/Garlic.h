/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef GARLIC_H
#define GARLIC_H

#include "IVeggies.h"

class Garlic : public IVeggies
{
public:
    Garlic();
    virtual ~Garlic();

    string ToString();
};

#endif // GARLIC_H
