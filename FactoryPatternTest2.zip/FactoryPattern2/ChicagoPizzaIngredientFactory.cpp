/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoPizzaIngredientFactory.h"
#include "ThickCrustDough.h"
#include "PlumTomatoSauce.h"
#include "MozzarellaCheese.h"
#include "BlackOlives.h"
#include "Spinach.h"
#include "Eggplant.h"
#include "SlicedPepperoni.h"
#include "FrozenClams.h"

ChicagoPizzaIngredientFactory::ChicagoPizzaIngredientFactory()
{
}

ChicagoPizzaIngredientFactory::~ChicagoPizzaIngredientFactory()
{
}

IDough *ChicagoPizzaIngredientFactory::CreateDough()
{
    return new ThickCrustDough();
}

ISauce *ChicagoPizzaIngredientFactory::CreateSauce()
{
    return new PlumTomatoSauce();
}

ICheese *ChicagoPizzaIngredientFactory::CreateCheese()
{
    return new MozzarellaCheese();
}

list<IVeggies*> ChicagoPizzaIngredientFactory::CreateVeggies()
{
    list<IVeggies*> veggiesList;
    veggiesList.push_back(new BlackOlives());
    veggiesList.push_back(new Spinach());
    veggiesList.push_back(new Eggplant());
    return veggiesList;
}

IPepperoni *ChicagoPizzaIngredientFactory::CreatePepperoni()
{
    return new SlicedPepperoni();
}

IClam *ChicagoPizzaIngredientFactory::CreateClam()
{
    return new FrozenClams();
}
