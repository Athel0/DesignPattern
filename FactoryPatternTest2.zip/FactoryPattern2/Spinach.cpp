/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Spinach.h"

Spinach::Spinach()
{
}

Spinach::~Spinach()
{
}

string Spinach::ToString()
{
    return "Spinach";
}
