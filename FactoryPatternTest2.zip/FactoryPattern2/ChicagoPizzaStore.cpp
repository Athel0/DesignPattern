/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoPizzaStore.h"
#include "ChicagoPizzaIngredientFactory.h"
#include "CheesePizza.h"
#include "VeggiePizza.h"
#include "PepperoniPizza.h"
#include "ClamPizza.h"
#include "CommonDefine.h"

ChicagoPizzaStore::ChicagoPizzaStore()
{
}

ChicagoPizzaStore::~ChicagoPizzaStore()
{
}

Pizza *ChicagoPizzaStore::CreatePizza(string type)
{
    Pizza *pizza = NULL;
    IPizzaIngredientFactory *ingredientFactory = new ChicagoPizzaIngredientFactory();

    if(0 == type.compare(STR_TYPE_CHEESE)){
        pizza = new CheesePizza(ingredientFactory);
        pizza->SetName("Chicago Style Cheese Pizza");
    }
    else if(0 == type.compare(STR_TYPE_VEGGIE)){
        pizza = new VeggiePizza(ingredientFactory);
        pizza->SetName("Chicago Style Veggie Pizza");
    }
    else if(0 == type.compare(STR_TYPE_PEPPERONI)){
        pizza = new PepperoniPizza(ingredientFactory);
        pizza->SetName("Chicago Style Pepperoni Pizza");
    }
    else if(0 == type.compare(STR_TYPE_CLAM)){
        pizza = new ClamPizza(ingredientFactory);
        pizza->SetName("Chicago Style Clam Pizza");
    }

    return pizza;
}
