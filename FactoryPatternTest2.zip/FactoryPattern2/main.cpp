#include <iostream>
#include "Pizza.h"
#include "NYPizzaStore.h"
#include "ChicagoPizzaStore.h"
#include "CommonDefine.h"

using namespace std;

int main()
{
    PizzaStore *nyStore = new NYPizzaStore();
    PizzaStore *chicagoStore = new ChicagoPizzaStore();

    Pizza *pizza = nyStore->OrderPizza(STR_TYPE_CHEESE);
    cout << "Ethan ordered a " << pizza->GetName() << endl << endl;

    pizza = chicagoStore->OrderPizza(STR_TYPE_CHEESE);
    cout << "Joel ordered a " << pizza->GetName() << endl << endl;

    pizza = nyStore->OrderPizza(STR_TYPE_CLAM);
    cout << "Ethan ordered a " << pizza->GetName() << endl << endl;

    pizza = chicagoStore->OrderPizza(STR_TYPE_CLAM);
    cout << "Joel ordered a " << pizza->GetName() << endl << endl;

    pizza = nyStore->OrderPizza(STR_TYPE_PEPPERONI);
    cout << "Ethan ordered a " << pizza->GetName() << endl << endl;

    pizza = chicagoStore->OrderPizza(STR_TYPE_PEPPERONI);
    cout << "Joel ordered a " << pizza->GetName() << endl << endl;

    pizza = nyStore->OrderPizza(STR_TYPE_VEGGIE);
    cout << "Ethan ordered a " << pizza->GetName() << endl << endl;

    pizza = chicagoStore->OrderPizza(STR_TYPE_VEGGIE);
    cout << "Joel ordered a " << pizza->GetName() << endl << endl;

    return 0;
}
