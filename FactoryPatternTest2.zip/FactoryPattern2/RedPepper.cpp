/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "RedPepper.h"

RedPepper::RedPepper()
{
}

RedPepper::~RedPepper()
{
}

string RedPepper::ToString()
{
    return "Red Pepper";
}
