/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef MARINARASAUCE_H
#define MARINARASAUCE_H

#include "ISauce.h"

class MarinaraSauce : public ISauce
{
public:
    MarinaraSauce();
    virtual ~MarinaraSauce();

    string ToString();
};

#endif // MARINARASAUCE_H
