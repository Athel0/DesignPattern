/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef THINCRUSTDOUGH_H
#define THINCRUSTDOUGH_H

#include "IDough.h"

class ThinCrustDough : public IDough
{
public:
    ThinCrustDough();
    virtual ~ThinCrustDough();

    string ToString();
};

#endif // THINCRUSTDOUGH_H
