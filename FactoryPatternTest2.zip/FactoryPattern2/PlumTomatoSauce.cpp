/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "PlumTomatoSauce.h"

PlumTomatoSauce::PlumTomatoSauce()
{
}

PlumTomatoSauce::~PlumTomatoSauce()
{
}

string PlumTomatoSauce::ToString()
{
    return "Tomato sauce with plum tomatoes";
}
