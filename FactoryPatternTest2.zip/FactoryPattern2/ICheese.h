#ifndef ICHEESE_H
#define ICHEESE_H

#include <iostream>
using namespace std;

class ICheese
{
public:
    ICheese()
    {
    }
    virtual ~ICheese()
    {
    }

    virtual string ToString() = 0;
};

#endif // ICHEESE_H
