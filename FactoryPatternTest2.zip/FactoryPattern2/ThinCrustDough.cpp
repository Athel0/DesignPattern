/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ThinCrustDough.h"

ThinCrustDough::ThinCrustDough()
{
}

ThinCrustDough::~ThinCrustDough()
{
}

string ThinCrustDough::ToString()
{
    return "Thin Crust Dough";
}
