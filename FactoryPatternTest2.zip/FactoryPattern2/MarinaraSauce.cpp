/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "MarinaraSauce.h"

MarinaraSauce::MarinaraSauce()
{
}

MarinaraSauce::~MarinaraSauce()
{
}

string MarinaraSauce::ToString()
{
    return "Marinara Sauce";
}
