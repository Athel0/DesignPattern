/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ThickCrustDough.h"

ThickCrustDough::ThickCrustDough()
{
}

ThickCrustDough::~ThickCrustDough()
{
}

string ThickCrustDough::ToString()
{
    return "ThickCrust style extra thick crust dough";
}
