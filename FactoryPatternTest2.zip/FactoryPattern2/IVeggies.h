#ifndef IVEGGIES_H
#define IVEGGIES_H

#include <iostream>
using namespace std;

class IVeggies
{
public:
    IVeggies()
    {
    }
    virtual ~IVeggies()
    {
    }

    virtual string ToString() = 0;
};

#endif // IVEGGIES_H
