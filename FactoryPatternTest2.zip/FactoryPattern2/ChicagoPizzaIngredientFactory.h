/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOPIZZAINGREDIENTFACTORY_H
#define CHICAGOPIZZAINGREDIENTFACTORY_H

#include "IPizzaIngredientFactory.h"

class ChicagoPizzaIngredientFactory : public IPizzaIngredientFactory
{
public:
    ChicagoPizzaIngredientFactory();
    virtual ~ChicagoPizzaIngredientFactory();

    IDough *CreateDough();
    ISauce *CreateSauce();
    ICheese *CreateCheese();
    list<IVeggies*> CreateVeggies();
    IPepperoni *CreatePepperoni();
    IClam *CreateClam();
};

#endif // CHICAGOPIZZAINGREDIENTFACTORY_H
