/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef REGGIANOCHEESE_H
#define REGGIANOCHEESE_H

#include "ICheese.h"

class ReggianoCheese : public ICheese
{
public:
    ReggianoCheese();
    virtual ~ReggianoCheese();

    string ToString();
};

#endif // REGGIANOCHEESE_H
