/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Tuner.h"

Tuner::Tuner(string description, Amplifier *amplifier)
{
    m_description = description;
    m_amplifier = amplifier;
}

Tuner::~Tuner()
{
}

void Tuner::On()
{
    cout << m_description << " On" << endl;
}

void Tuner::Off()
{
    cout << m_description << " Off" << endl;
}

void Tuner::SetFrequency(double frequency)
{
    cout << m_description << " Setting Frequency To " << frequency << endl;
    m_frequency = frequency;
}

void Tuner::SetAm()
{
    cout << m_description << " Setting AM Mode" << endl;
}

void Tuner::SetFm()
{
    cout << m_description << " Setting FM Mode" << endl;
}

string Tuner::ToString()
{
    return m_description;
}
