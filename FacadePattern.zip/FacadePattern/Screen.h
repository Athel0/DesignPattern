/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef SCREEN_H
#define SCREEN_H

#include <iostream>
using namespace std;

class Screen
{
public:
    Screen(string description);
    virtual ~Screen();

    void Up();
    void Down();
    string ToString();

private:
    string m_description;
};

#endif // SCREEN_H
