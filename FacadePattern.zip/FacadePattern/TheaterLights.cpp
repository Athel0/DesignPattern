/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "TheaterLights.h"

TheaterLights::TheaterLights(string description)
{
    m_description = description;
}

TheaterLights::~TheaterLights()
{
}

void TheaterLights::On()
{
    cout << m_description << " On" << endl;
}

void TheaterLights::Off()
{
    cout << m_description << " Off" << endl;
}

void TheaterLights::Dim(int level)
{
    cout << m_description << " Diming To " << level << "%" << endl;
}

string TheaterLights::ToString()
{
    return m_description;
}
