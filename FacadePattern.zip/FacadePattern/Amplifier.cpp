/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Amplifier.h"
#include "CdPlayer.h"
#include "DvdPlayer.h"
#include "Tuner.h"

Amplifier::Amplifier(string descrition)
{
    m_description = descrition;
}

Amplifier::~Amplifier()
{
}

void Amplifier::On()
{
    cout << m_description << " On" << endl;
}

void Amplifier::Off()
{
    cout << m_description << " Off" << endl;
}

void Amplifier::SetStereoSound()
{
    cout << m_description << " Stereo Mode On" << endl;
}

void Amplifier::SetSurroundSound()
{
    cout << m_description << " Surround Sound On (5 speakers, 1 subwoofer)" << endl;
}

void Amplifier::SetVolume(int level)
{
    cout << m_description << " Setting Volume To" << level << endl;
}

void Amplifier::SetTuner(Tuner *tuner)
{
    cout << m_description << " Setting Tuner To " << tuner << endl;
    m_tuner = tuner;
}

void Amplifier::SetDvd(DvdPlayer *dvd)
{
    cout << m_description << " Setting Dvd To " << dvd << endl;
    m_dvdPlayer = dvd;
}

void Amplifier::SetCd(CdPlayer *cd)
{
    cout << m_description << " Setting Cd To " << cd << endl;
    m_cdPlayer = cd;
}

string Amplifier::ToString()
{
    return m_description;
}
