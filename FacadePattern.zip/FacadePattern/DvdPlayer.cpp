/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "DvdPlayer.h"
#include "Amplifier.h"

DvdPlayer::DvdPlayer(string description, Amplifier *amplifier)
{
    m_description = description;
    m_amplifier = amplifier;
}

DvdPlayer::~DvdPlayer()
{
}

void DvdPlayer::On()
{
    cout << m_description << " On" << endl;
}

void DvdPlayer::Off()
{
    cout << m_description << " Off" << endl;
}

void DvdPlayer::Eject()
{
    m_movie = "";
    cout << m_description << " Eject" << endl;
}

void DvdPlayer::Play(string movie)
{
    m_movie = movie;
    m_currentTrack = 0;
    cout << m_description << " Playing \"" << m_movie << "\"" << endl;
}

void DvdPlayer::Play(int track)
{
    if("" == m_movie){
        cout << m_description << " Can't Play Track " << m_currentTrack << " No Dvd Inserted" << endl;
    }
    else{
        m_currentTrack = track;
        cout << m_description << " Playing Track " << m_currentTrack << " Of \"" << m_movie << "\"" << endl;
    }
}

void DvdPlayer::Stop()
{
    m_currentTrack = 0;
    cout << m_description << " Stopped \"" << m_movie << "\"" << endl;
}

void DvdPlayer::Pause()
{
    cout << m_description << " Paused \"" << m_movie << "\"" << endl;
}

void DvdPlayer::SetTwoChannelAudio()
{
    cout << m_description << " Set Two Channel Audio" << endl;
}

void DvdPlayer::SetSurroundAudio()
{
    cout << m_description << " Set Surround Audio" << endl;
}

string DvdPlayer::ToString()
{
    return m_description;
}
