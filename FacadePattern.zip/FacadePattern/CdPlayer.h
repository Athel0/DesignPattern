/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CDPLAYER_H
#define CDPLAYER_H

#include <iostream>
using namespace std;

class Amplifier;

class CdPlayer
{
public:
    CdPlayer(string description, Amplifier *amplifier);
    virtual ~CdPlayer();

    void On();
    void Off();
    void Eject();
    void Play(string title);
    void Play(int track);
    void Stop();
    void Pause();
    string ToString();

private:
    string m_description;
    Amplifier *m_amplifier;
    int m_currentTrack;
    string m_title;
};

#endif // CDPLAYER_H
