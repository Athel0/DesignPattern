/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef THEATERLIGHTS_H
#define THEATERLIGHTS_H

#include <iostream>
using namespace std;

class TheaterLights
{
public:
    TheaterLights(string description);
    virtual ~TheaterLights();

    void On();
    void Off();
    void Dim(int level);
    string ToString();

private:
    string m_description;
};

#endif // THEATERLIGHTS_H
