/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Screen.h"

Screen::Screen(string description)
{
    m_description = description;
}

Screen::~Screen()
{
}

void Screen::Up()
{
    cout << m_description << " Going Up" << endl;
}

void Screen::Down()
{
    cout << m_description << " Going Down" << endl;
}

string Screen::ToString()
{
    return m_description;
}
