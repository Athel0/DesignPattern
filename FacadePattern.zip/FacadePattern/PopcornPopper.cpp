/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "PopcornPopper.h"

PopcornPopper::PopcornPopper(string description)
{
    m_description = description;
}

PopcornPopper::~PopcornPopper()
{
}

void PopcornPopper::On()
{
    cout << m_description << " On" << endl;
}

void PopcornPopper::Off()
{
    cout << m_description << " Off" << endl;
}

void PopcornPopper::Pop()
{
    cout << m_description << " Popping Popcon!" << endl;
}

string PopcornPopper::ToString()
{
    return m_description;
}
