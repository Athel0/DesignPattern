/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef HOMETHEATERFACADE_H
#define HOMETHEATERFACADE_H

#include <iostream>
#include "Amplifier.h"
#include "Tuner.h"
#include "DvdPlayer.h"
#include "CdPlayer.h"
#include "Projector.h"
#include "Screen.h"
#include "TheaterLights.h"
#include "PopcornPopper.h"

using namespace std;

class HomeTheaterFacade
{
public:
    HomeTheaterFacade(Amplifier *amp,
                      Tuner *tuner,
                      DvdPlayer *dvd,
                      CdPlayer *cd,
                      Projector *projector,
                      Screen *screen,
                      TheaterLights *lights,
                      PopcornPopper *popper);
    virtual ~HomeTheaterFacade();

    void WatchMovie(string movie);
    void EndMovie();
    void ListenToCd(string cdTitle);
    void EndCd();
    void ListenToRadio(double frequency);
    void EndRadio();

private:
    Amplifier *m_amp;
    CdPlayer *m_cd;
    DvdPlayer *m_dvd;
    PopcornPopper *m_popper;
    Projector *m_projector;
    Screen *m_screen;
    TheaterLights *m_lights;
    Tuner *m_tuner;
};

#endif // HOMETHEATERFACADE_H
