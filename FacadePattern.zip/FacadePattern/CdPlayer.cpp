/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "CdPlayer.h"
#include "Amplifier.h"

CdPlayer::CdPlayer(string description, Amplifier *amplifier)
{
    m_description = description;
    m_amplifier = amplifier;
}

CdPlayer::~CdPlayer()
{
}

void CdPlayer::On()
{
    cout << m_description << " On" << endl;
}

void CdPlayer::Off()
{
    cout << m_description << " Off" << endl;
}

void CdPlayer::Eject()
{
    m_title = "";
    cout << m_description << " Eject" << endl;
}

void CdPlayer::Play(string title)
{
    m_title = title;
    m_currentTrack = 0;
    cout << m_description << " Playing \"" << m_title << "\"" << endl;
}

void CdPlayer::Play(int track)
{
    if("" == m_title){
        cout << m_description << " Can't Play Track " << m_currentTrack
             <<	", No Cd Inserted" << endl;
    }
    else{
        m_currentTrack = track;
        cout << m_description << " Playing Track " << m_currentTrack << endl;
    }
}

void CdPlayer::Stop()
{
    m_currentTrack = 0;
    cout << m_description << " Stopped" << endl;
}

void CdPlayer::Pause()
{
    cout << m_description << " Paused \"" << m_title << "\"" << endl;
}

string CdPlayer::ToString()
{
    return m_description;
}
