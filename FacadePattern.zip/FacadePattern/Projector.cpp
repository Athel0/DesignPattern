/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Projector.h"
#include "DvdPlayer.h"

Projector::Projector(string description, DvdPlayer *dvdPlayer)
{
    m_description = description;
    m_dvdPlayer = dvdPlayer;
}

Projector::~Projector()
{
}

void Projector::On()
{
    cout << m_description << " On" << endl;
}

void Projector::Off()
{
    cout << m_description << " Off" << endl;
}

void Projector::WideScreenMode()
{
    cout << m_description << " In WideScreen Mode (16x9 aspect ratio)" << endl;
}

void Projector::TvMode()
{
    cout << m_description << " In TV Mode (4x3 aspect ratio)" << endl;
}

string Projector::ToString()
{
    return m_description;
}
