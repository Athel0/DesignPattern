/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef PROJECTOR_H
#define PROJECTOR_H

#include <iostream>
using namespace std;

class DvdPlayer;

class Projector
{
public:
    Projector(string description, DvdPlayer *dvdPlayer);
    virtual ~Projector();

    void On();
    void Off();
    void WideScreenMode();
    void TvMode();
    string ToString();

private:
    string m_description;
    DvdPlayer *m_dvdPlayer;
};

#endif // PROJECTOR_H
