/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef AMPLIFIER_H
#define AMPLIFIER_H

#include <iostream>
using namespace std;

class CdPlayer;
class DvdPlayer;
class Tuner;

class Amplifier
{
public:
    Amplifier(string descrition);
    virtual ~Amplifier();

    void On();
    void Off();
    void SetStereoSound();
    void SetSurroundSound();
    void SetVolume(int level);
    void SetTuner(Tuner *tuner);
    void SetDvd(DvdPlayer *dvd);
    void SetCd(CdPlayer *cd);
    string ToString();

private:
    string m_description;
    Tuner *m_tuner;
    DvdPlayer *m_dvdPlayer;
    CdPlayer *m_cdPlayer;
};

#endif // AMPLIFIER_H
