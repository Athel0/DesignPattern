/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef TUNER_H
#define TUNER_H

#include <iostream>
using namespace std;

class Amplifier;

class Tuner
{
public:
    Tuner(string description, Amplifier *amplifier);
    virtual ~Tuner();

    void On();
    void Off();
    void SetFrequency(double frequency);
    void SetAm();
    void SetFm();
    string ToString();

private:
    string m_description;
    Amplifier *m_amplifier;
    double m_frequency;
};

#endif // TUNER_H
