/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef POPCORNPOPPER_H
#define POPCORNPOPPER_H

#include <iostream>
using namespace std;

class PopcornPopper
{
public:
    PopcornPopper(string description);
    virtual ~PopcornPopper();

    void On();
    void Off();
    void Pop();
    string ToString();

private:
    string m_description;
};

#endif // POPCORNPOPPER_H
