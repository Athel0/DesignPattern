/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef DVDPLAYER_H
#define DVDPLAYER_H

#include <iostream>
using namespace std;

class Amplifier;

class DvdPlayer
{
public:
    DvdPlayer(string description, Amplifier *amplifier);
    virtual ~DvdPlayer();

    void On();
    void Off();
    void Eject();
    void Play(string movie);
    void Play(int track);
    void Stop();
    void Pause();
    void SetTwoChannelAudio();
    void SetSurroundAudio();
    string ToString();

private:
    string m_description;
    Amplifier *m_amplifier;
    int m_currentTrack;
    string m_movie;
};

#endif // DVDPLAYER_H
