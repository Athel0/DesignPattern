/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHANFEIZIOBSERVABLE_H
#define CHANFEIZIOBSERVABLE_H

#include "IObservable.h"
#include "IObserver.h"

#include <iostream>
#include <list>

using namespace std;

class CHanFeiZiObservable : public IObservable
{
    public:
        CHanFeiZiObservable();
        virtual ~CHanFeiZiObservable();

        void AddObserver(IObserver *pObserver);
        void DeleteObserver(IObserver *pObserver);
        void NotifyObserver(string context);
        void HaveBreakfast();
        void HaveFun();

    private:
        list<IObserver*> m_observerList;
        typedef list<IObserver*>::iterator ObserverList_iterator;
};

#endif // CHANFEIZIOBSERVABLE_H
