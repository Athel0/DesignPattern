/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CLISIOBSERVER_H
#define CLISIOBSERVER_H

#include "IObserver.h"
#include <iostream>

using namespace std;

class CLiSiObserver : public IObserver
{
    public:
        CLiSiObserver();
        virtual ~CLiSiObserver();

        void Update(string context);
        string GetName();

    private:
        void ReportToQinShiHuang(string report);
};

#endif // CLISIOBSERVER_H
