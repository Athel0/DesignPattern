/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "CZhouSiObserver.h"

CZhouSiObserver::CZhouSiObserver()
    : IObserver("ZhouSi")
{
}

CZhouSiObserver::~CZhouSiObserver()
{
}

void CZhouSiObserver::Update(string context)
{
    cout << "ZhouSi: HanFeiZi begins to active and he hismself begins to active..." << endl;
    this->Cry(context);
    cout << "ZhouSi: Is crying..." << endl;
}

string CZhouSiObserver::GetName()
{
    return m_name;
}

void CZhouSiObserver::Cry(string report)
{
    cout << "ZhouSi: Because " << report.c_str() << ", then I am crying..." << endl;
}
