#include "IObserver.h"
#include "IObservable.h"
#include "CHanFeiZiObservable.h"
#include "CLiSiObserver.h"
#include "CZhouSiObserver.h"
#include <iostream>

using namespace std;

void Do()
{
    IObserver *pLiSi = new CLiSiObserver();
    IObserver *pZhouSi = new CZhouSiObserver();

    CHanFeiZiObservable *pHanFeiZi = new CHanFeiZiObservable();

    pHanFeiZi->AddObserver(pLiSi);
    pHanFeiZi->AddObserver(pZhouSi);
    pHanFeiZi->HaveBreakfast();

    delete pLiSi;
    pLiSi = NULL;
    delete pZhouSi;
    pZhouSi = NULL;
}

int main()
{
    //cout << "Hello world!" << endl;
    Do();

    return 0;
}
