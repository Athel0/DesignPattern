#ifndef IOBSERVABLE_H
#define IOBSERVABLE_H

#include "IObserver.h"
#include <iostream>

using namespace std;

class IObservable
{
    public:
        IObservable()
        {
        }
        virtual ~IObservable()
        {
        }

        virtual void AddObserver(IObserver *pObserver) = 0;
        virtual void DeleteObserver(IObserver *pObserver) = 0;
        virtual void NotifyObserver(string context) = 0;
};

#endif // IOBSERVABLE_H
