/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "CLiSiObserver.h"

CLiSiObserver::CLiSiObserver()
    : IObserver("LiSi")
{
}

CLiSiObserver::~CLiSiObserver()
{
}

void CLiSiObserver::Update(string context)
{
    cout << "LiSi: Begin to observer and report to boss..." << endl;
    this->ReportToQinShiHuang(context);
    cout << "LiSi: Observer end..." << endl;
}

string CLiSiObserver::GetName()
{
    return m_name;
}

void CLiSiObserver::ReportToQinShiHuang(string report)
{
    cout << "LiSi: Hi, Boss! HanFeiZi begins to active ---> " << report.c_str() << endl;
}
