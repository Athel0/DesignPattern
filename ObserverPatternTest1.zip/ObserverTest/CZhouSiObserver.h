/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CZHOUSIOBSERVER_H
#define CZHOUSIOBSERVER_H

#include "IObserver.h"
#include <iostream>

using namespace std;

class CZhouSiObserver : public IObserver
{
    public:
        CZhouSiObserver();
        virtual ~CZhouSiObserver();

        void Update(string context);
        string GetName();

    private:
        void Cry(string report);
};

#endif // CZHOUSIOBSERVER_H
