/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "CHanFeiZiObservable.h"

CHanFeiZiObservable::CHanFeiZiObservable()
{
}

CHanFeiZiObservable::~CHanFeiZiObservable()
{
}

void CHanFeiZiObservable::AddObserver(IObserver *pObserver)
{
    m_observerList.push_back(pObserver);
}

void CHanFeiZiObservable::DeleteObserver(IObserver *pObserver)
{
    ObserverList_iterator it = m_observerList.begin();
    for(; it != m_observerList.end(); it++)
    {
        string name = (*it)->GetName();
        if(0 == name.compare(pObserver->GetName()))
        {
            m_observerList.erase(it);
        }
    }
}

void CHanFeiZiObservable::NotifyObserver(string context)
{
    ObserverList_iterator it = m_observerList.begin();
    for(; it != m_observerList.end(); it++)
    {
        (*it)->Update(context);
    }
}

void CHanFeiZiObservable::HaveBreakfast()
{
    cout << "HanFeiZi: Have Breakfast..." << endl;
    this->NotifyObserver("HanFeiZi is having breakfast.");
}

void CHanFeiZiObservable::HaveFun()
{
    cout << "HanFeiZi: Have Fun..." << endl;
    this->NotifyObserver("HanFeiZi is having fun.");
}
