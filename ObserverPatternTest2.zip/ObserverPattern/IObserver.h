#ifndef IOBSERVER_H
#define IOBSERVER_H

#include <iostream>
using namespace std;

class IObserver
{
public:
    IObserver(string name)
    {
        m_name = name;
    }
    virtual ~IObserver()
    {
    }

    virtual void Update(float temp, float humidity, float pressure) = 0;
    virtual string GetName() = 0;

protected:
    string m_name;
};

#endif // IOBSERVER_H
