#ifndef COMMONDEFINE_H
#define COMMONDEFINE_H

#define STR_CURRENTCONDITIONS   "CurrentConditions"
#define STR_STATISTICSDISPLAY   "StatisticsDisplay"
#define STR_FORECASTDISPLAY     "ForecastDisplay"

#endif // COMMONDEFINE
