/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include <iostream>
#include "StatisticsDisplay.h"
#include "CommonDefine.h"

using namespace std;

StatisticsDisplay::StatisticsDisplay()
    : IObserver(STR_STATISTICSDISPLAY)
    , m_maxTemp(0.0f)
    , m_minTemp(200)
    , m_tempSum(0.0f)
    , m_numReadings(0)
{
}

StatisticsDisplay::~StatisticsDisplay()
{
}

string StatisticsDisplay::GetName()
{
    return m_name;
}

void StatisticsDisplay::Update(float temp, float humidity, float pressure)
{
    m_tempSum += temp;
    m_numReadings++;

    if(temp > m_maxTemp){
        m_maxTemp = temp;
    }

    if(temp < m_minTemp){
        m_minTemp = temp;
    }

    Display();
}

void StatisticsDisplay::Display()
{
    cout << "Avg/Max/Min temperature = " << (m_tempSum / m_numReadings)
            << "/" << m_maxTemp << "/" << m_minTemp << endl;
}
