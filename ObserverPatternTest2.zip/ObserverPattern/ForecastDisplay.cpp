/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include <iostream>
#include "ForecastDisplay.h"
#include "CommonDefine.h"

using namespace std;

ForecastDisplay::ForecastDisplay()
    : IObserver(STR_FORECASTDISPLAY)
    , m_currentPressure(29.92f)
    , m_lastPressure(0.0f)
{
}

ForecastDisplay::~ForecastDisplay()
{
}

string ForecastDisplay::GetName(){
    return m_name;
}

void ForecastDisplay::Update(float temp, float humidity, float pressure)
{
    m_lastPressure = m_currentPressure;
    m_currentPressure = pressure;

    Display();
}

void ForecastDisplay::Display()
{
    cout << "Forcast: ";
    if(m_currentPressure > m_lastPressure){
        cout << "Improving weather on the way!" << endl;
    }
    else if(m_currentPressure == m_lastPressure){
        cout << "More of the same!" << endl;
    }
    else if(m_currentPressure < m_lastPressure){
        cout << "Watch out for cooler, rainy weather!" << endl;
    }
}
