#include <iostream>
#include "WeatherData.h"
#include "CurrentConditionsDisplay.h"
#include "ForecastDisplay.h"
#include "StatisticsDisplay.h"

using namespace std;

int main()
{
    CurrentConditionsDisplay *currentConditions = new CurrentConditionsDisplay();
    ForecastDisplay *forecastDisplay = new ForecastDisplay();
    StatisticsDisplay *statisticsDisplay = new StatisticsDisplay();

    WeatherData *weatherData = new WeatherData();
    weatherData->RegisterObserver(currentConditions);
    weatherData->RegisterObserver(forecastDisplay);
    weatherData->RegisterObserver(statisticsDisplay);

    weatherData->SetMeasurements(80, 65, 30.4f);
    weatherData->SetMeasurements(82, 70, 29.2f);
    weatherData->SetMeasurements(78, 90, 29.2f);
    return 0;
}
