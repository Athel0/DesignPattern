/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "WeatherData.h"

WeatherData::WeatherData()
{
}

WeatherData::~WeatherData()
{
}

void WeatherData::RegisterObserver(IObserver *pObserver)
{
    m_observerList.push_back(pObserver);
}

void WeatherData::RemoveObserver(IObserver *pObserver)
{
    ObserverList_iterator it = m_observerList.begin();
    for(; it != m_observerList.end(); it++){
        string name = (*it)->GetName();

        if(0 == name.compare(pObserver->GetName())){
            m_observerList.erase(it);
        }
    }
}

void WeatherData::NotifyObserver()
{
    ObserverList_iterator it = m_observerList.begin();
    for(; it != m_observerList.end(); it++){
        (*it)->Update(m_temperature, m_humidity, m_pressure);
    }
}

void WeatherData::MeasurementsChanged()
{
    NotifyObserver();
}

void WeatherData::SetMeasurements(float temperature, float humidity, float pressure)
{
    m_temperature = temperature;
    m_humidity = humidity;
    m_pressure = pressure;
    MeasurementsChanged();
}

float WeatherData::GetTemperature()
{
    return m_temperature;
}

float WeatherData::GetHumidity()
{
    return m_humidity;
}

float WeatherData::GetPressure()
{
    return m_pressure;
}
