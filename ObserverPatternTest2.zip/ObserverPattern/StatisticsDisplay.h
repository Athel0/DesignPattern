/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef STATISTICSDISPLAY_H
#define STATISTICSDISPLAY_H

#include "IObserver.h"
#include "IDisplayElement.h"

class StatisticsDisplay : public IObserver, public IDisplayElement
{
public:
    StatisticsDisplay();
    virtual ~StatisticsDisplay();

    string GetName();
    void Update(float temp, float humidity, float pressure);
    void Display();

private:
    float m_maxTemp;
    float m_minTemp;
    float m_tempSum;
    int m_numReadings;
};

#endif // STATISTICSDISPLAY_H
