/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef WEATHERDATA_H
#define WEATHERDATA_H

#include <list>
#include "IObservable.h"

using namespace std;

class WeatherData : public IObservable
{
public:
    WeatherData();
    virtual ~WeatherData();

    void RegisterObserver(IObserver *pObserver);
    void RemoveObserver(IObserver *pObserver);
    void NotifyObserver();

    void MeasurementsChanged();
    void SetMeasurements(float temperature, float humidity, float pressure);

    float GetTemperature();
    float GetHumidity();
    float GetPressure();

private:
    list<IObserver*> m_observerList;
    typedef list<IObserver*>::iterator ObserverList_iterator;

    float m_temperature;
    float m_humidity;
    float m_pressure;
};

#endif // WEATHERDATA_H
