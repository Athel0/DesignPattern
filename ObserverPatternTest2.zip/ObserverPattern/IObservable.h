#ifndef IOBSERVABLE_H
#define IOBSERVABLE_H

#include "IObserver.h"

class IObservable
{
public:
    IObservable()
    {
    }
    virtual ~IObservable()
    {
    }

    virtual void RegisterObserver(IObserver *pObserver) = 0;
    virtual void RemoveObserver(IObserver *pObserver) = 0;
    virtual void NotifyObserver() = 0;
};

#endif // IOBSERVABLE_H
