/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef FORECASTDISPLAY_H
#define FORECASTDISPLAY_H

#include "IObserver.h"
#include "IDisplayElement.h"

class ForecastDisplay : public IObserver, public IDisplayElement
{
public:
    ForecastDisplay();
    virtual ~ForecastDisplay();

    string GetName();
    void Update(float temp, float humidity, float pressure);
    void Display();

private:
    float m_currentPressure;
    float m_lastPressure;
};

#endif // FORECASTDISPLAY_H
