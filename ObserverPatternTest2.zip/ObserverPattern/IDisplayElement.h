#ifndef IDISPLAYELEMENT_H
#define IDISPLAYELEMENT_H

class IDisplayElement
{
public:
    IDisplayElement()
    {
    }
    virtual ~IDisplayElement()
    {
    }

    virtual void Display() = 0;
};

#endif // IDISPLAYELEMENT_H
