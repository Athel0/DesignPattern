/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include <iostream>
#include "CurrentConditionsDisplay.h"
#include "CommonDefine.h"

using namespace std;

CurrentConditionsDisplay::CurrentConditionsDisplay()
    : IObserver(STR_CURRENTCONDITIONS)
    , m_temperature(0.0f)
    , m_humidity(0.0f)
{
}

CurrentConditionsDisplay::~CurrentConditionsDisplay()
{
}

string CurrentConditionsDisplay::GetName()
{
    return m_name;
}

void CurrentConditionsDisplay::Update(float temperature, float humidity, float pressure)
{
    m_temperature = temperature;
    m_humidity = humidity;
    Display();
}

void CurrentConditionsDisplay::Display()
{
    cout << "Current conditions: " << m_temperature
        << "F degrees and " << m_humidity << "% humidity" << endl;
}
