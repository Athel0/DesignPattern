/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CURRENTCONDITIONSDISPLAY_H
#define CURRENTCONDITIONSDISPLAY_H

#include "IObserver.h"
#include "IDisplayElement.h"

class CurrentConditionsDisplay : public IObserver, public IDisplayElement
{
public:
    CurrentConditionsDisplay();
    virtual ~CurrentConditionsDisplay();

    string GetName();
    void Update(float temperature, float humidity, float pressure);
    void Display();

private:
    float m_temperature;
    float m_humidity;
};

#endif // CURRENTCONDITIONSDISPLAY_H
