/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYStyleCheesePizza.h"

NYStyleCheesePizza::NYStyleCheesePizza()
{
    m_name = "NY Style Sauce and Cheese Pizza";
    m_dough = "Thin Crust Dough";
    m_sauce = "Marinara Sauce";

    m_toppings.push_back("Grated Reggiano Cheese");
}

NYStyleCheesePizza::~NYStyleCheesePizza()
{
}
