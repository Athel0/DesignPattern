/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoStylePepperoniPizza.h"

ChicagoStylePepperoniPizza::ChicagoStylePepperoniPizza()
{
    m_name = "Chicago Style Pepperoni Pizza";
    m_dough = "Extra Thick Crust Dough";
    m_sauce = "Plum Tomato Sauce";

    m_toppings.push_back("Shredded Mozzarella Cheese");
    m_toppings.push_back("Black Olives");
    m_toppings.push_back("Spinach");
    m_toppings.push_back("Eggplant");
    m_toppings.push_back("Sliced Pepperoni");
}

ChicagoStylePepperoniPizza::~ChicagoStylePepperoniPizza()
{
}

void ChicagoStylePepperoniPizza::Cut()
{
    cout << "Cutting the pizza into square slices" << endl;
}
