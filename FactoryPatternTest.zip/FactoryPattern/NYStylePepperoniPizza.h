/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYSTYLEPEPPERONIPIZZA_H
#define NYSTYLEPEPPERONIPIZZA_H

#include "Pizza.h"

class NYStylePepperoniPizza : public Pizza
{
public:
    NYStylePepperoniPizza();
    virtual ~NYStylePepperoniPizza();
};

#endif // NYSTYLEPEPPERONIPIZZA_H
