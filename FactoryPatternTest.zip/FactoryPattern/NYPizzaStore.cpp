/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYPizzaStore.h"
#include "CommonDefine.h"

#include "NYStyleCheesePizza.h"
#include "NYStyleVeggiePizza.h"
#include "NYStyleClamPizza.h"
#include "NYStylePepperoniPizza.h"

NYPizzaStore::NYPizzaStore()
{
}

NYPizzaStore::~NYPizzaStore()
{
}

Pizza *NYPizzaStore::CreatePizza(string type)
{
    if(0 == type.compare(STR_TYPE_CHEESE)){
        return new NYStyleCheesePizza();
    }
    else if(0 == type.compare(STR_TYPE_VEGGIE)){
        return new NYStyleVeggiePizza();
    }
    else if(0 == type.compare(STR_TYPE_CLAM)){
        return new NYStyleClamPizza();
    }
    else if(0 == type.compare(STR_TYPE_PEPPERONI)){
        return new NYStylePepperoniPizza();
    }
    else{
        return NULL;
    }
}
