/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYStyleVeggiePizza.h"

NYStyleVeggiePizza::NYStyleVeggiePizza()
{
    m_name = "NY Style Veggie Pizza";
    m_dough = "Thin Crust Dough";
	m_sauce = "Marinara Sauce";

 	m_toppings.push_back("Grated Reggiano Cheese");
	m_toppings.push_back("Garlic");
	m_toppings.push_back("Onion");
	m_toppings.push_back("Mushrooms");
	m_toppings.push_back("Red Pepper");
}

NYStyleVeggiePizza::~NYStyleVeggiePizza()
{
}
