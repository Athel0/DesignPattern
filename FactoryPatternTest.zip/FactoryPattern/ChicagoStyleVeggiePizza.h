/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOSTYLEVEGGIEPIZZA_H
#define CHICAGOSTYLEVEGGIEPIZZA_H

#include "Pizza.h"

class ChicagoStyleVeggiePizza : public Pizza
{
public:
    ChicagoStyleVeggiePizza();
    virtual ~ChicagoStyleVeggiePizza();

    void Cut();
};

#endif // CHICAGOSTYLEVEGGIEPIZZA_H
