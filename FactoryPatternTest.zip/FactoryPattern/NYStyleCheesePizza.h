/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYSTYLECHEESEPIZZA_H
#define NYSTYLECHEESEPIZZA_H

#include "Pizza.h"

class NYStyleCheesePizza : public Pizza
{
public:
    NYStyleCheesePizza();
    virtual ~NYStyleCheesePizza();
};

#endif // NYSTYLECHEESEPIZZA_H
