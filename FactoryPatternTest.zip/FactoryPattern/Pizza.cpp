/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "Pizza.h"

Pizza::Pizza()
{
}

Pizza::~Pizza()
{
}

void Pizza::Prepare()
{
    cout << "Preparing " << m_name << "\n"
         << "Tossing dough...\n"
         << "Adding sauce...\n"
         << "Add toppings: ";

    for(unsigned int i = 0; i < m_toppings.size(); i++){
        cout << " " << m_toppings.at(i);
    }

    cout << endl;
}

void Pizza::Bake()
{
    cout << "Bake for 25 minutes at 350" << endl;
}

void Pizza::Cut()
{
    cout << "Cutting the pizza into diagonal slices" << endl;
}

void Pizza::Box()
{
    cout << "Place pizza in official PizzaStore box" << endl;
}

string Pizza::GetName()
{
    return m_name;
}
