/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOSTYLECHEESEPIZZA_H
#define CHICAGOSTYLECHEESEPIZZA_H

#include "Pizza.h"

class ChicagoStyleCheesePizza : public Pizza
{
public:
    ChicagoStyleCheesePizza();
    virtual ~ChicagoStyleCheesePizza();

    void Cut();
};

#endif // CHICAGOSTYLECHEESEPIZZA_H
