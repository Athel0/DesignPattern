/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoStyleClamPizza.h"

ChicagoStyleClamPizza::ChicagoStyleClamPizza()
{
    m_name = "Chicago Style Clam Pizza";
    m_dough = "Extra Thick Crust Dough";
    m_sauce = "Plum Tomato Sauce";

    m_toppings.push_back("Shredded Mozzarella Cheese");
    m_toppings.push_back("Frozen Clams from Chesapeake Bay");
}

ChicagoStyleClamPizza::~ChicagoStyleClamPizza()
{
}

void ChicagoStyleClamPizza::Cut()
{
    cout << "Cutting the pizza into square slices" << endl;
}
