/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoStyleCheesePizza.h"

ChicagoStyleCheesePizza::ChicagoStyleCheesePizza()
{
    m_name = "Chicago Style Deep Dish Cheese Pizza";
    m_dough = "Extra Thick Crust Dough";
    m_sauce = "Plum Tomato Sauce";

    m_toppings.push_back("Shredded Mozzarella Cheese");
}

ChicagoStyleCheesePizza::~ChicagoStyleCheesePizza()
{
}

void ChicagoStyleCheesePizza::Cut()
{
    cout << "Cutting the pizza into square slices" << endl;
}
