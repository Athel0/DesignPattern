/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef PIZZA_H
#define PIZZA_H

#include <iostream>
#include <vector>

using  namespace std;

class Pizza
{
public:
    Pizza();
    virtual ~Pizza();

    void Prepare();
    void Bake();
    void Cut();
    void Box();
    string GetName();

protected:
    string m_name;
    string m_dough;
    string m_sauce;
    vector<string> m_toppings;
};

#endif // PIZZA_H
