/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYStylePepperoniPizza.h"

NYStylePepperoniPizza::NYStylePepperoniPizza()
{
    m_name = "NY Style Pepperoni Pizza";
    m_dough = "Thin Crust Dough";
    m_sauce = "Marinara Sauce";

    m_toppings.push_back("Grated Reggiano Cheese");
    m_toppings.push_back("Sliced Pepperoni");
    m_toppings.push_back("Garlic");
    m_toppings.push_back("Onion");
    m_toppings.push_back("Mushrooms");
    m_toppings.push_back("Red Pepper");
}

NYStylePepperoniPizza::~NYStylePepperoniPizza()
{
}
