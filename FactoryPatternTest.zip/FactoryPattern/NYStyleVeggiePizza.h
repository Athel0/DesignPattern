/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYSTYLEVEGGIEPIZZA_H
#define NYSTYLEVEGGIEPIZZA_H

#include "Pizza.h"

class NYStyleVeggiePizza : public Pizza
{
public:
    NYStyleVeggiePizza();
    virtual ~NYStyleVeggiePizza();
};

#endif // NYSTYLEVEGGIEPIZZA_H
