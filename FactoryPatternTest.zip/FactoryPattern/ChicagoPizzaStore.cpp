/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoPizzaStore.h"
#include "CommonDefine.h"

#include "ChicagoStyleCheesePizza.h"
#include "ChicagoStyleVeggiePizza.h"
#include "ChicagoStyleClamPizza.h"
#include "ChicagoStylePepperoniPizza.h"

ChicagoPizzaStore::ChicagoPizzaStore()
{
}

ChicagoPizzaStore::~ChicagoPizzaStore()
{
}

Pizza *ChicagoPizzaStore::CreatePizza(string type)
{
    if(0 == type.compare(STR_TYPE_CHEESE)){
        return new ChicagoStyleCheesePizza();
    }
    else if(0 == type.compare(STR_TYPE_VEGGIE)){
        return new ChicagoStyleVeggiePizza();
    }
    else if(0 == type.compare(STR_TYPE_CLAM)){
        return new ChicagoStyleClamPizza();
    }
    else if(0 == type.compare(STR_TYPE_PEPPERONI)){
        return new ChicagoStylePepperoniPizza();
    }
    else{
        return NULL;
    }
}
