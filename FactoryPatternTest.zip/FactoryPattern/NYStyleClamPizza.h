/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef NYSTYLECLAMPIZZA_H
#define NYSTYLECLAMPIZZA_H

#include "Pizza.h"

class NYStyleClamPizza : public Pizza
{
public:
    NYStyleClamPizza();
    virtual ~NYStyleClamPizza();
};

#endif // NYSTYLECLAMPIZZA_H
