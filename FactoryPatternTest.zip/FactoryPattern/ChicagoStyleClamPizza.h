/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOSTYLECLAMPIZZA_H
#define CHICAGOSTYLECLAMPIZZA_H

#include "Pizza.h"

class ChicagoStyleClamPizza : public Pizza
{
public:
    ChicagoStyleClamPizza();
    virtual ~ChicagoStyleClamPizza();

    void Cut();
};

#endif // CHICAGOSTYLECLAMPIZZA_H
