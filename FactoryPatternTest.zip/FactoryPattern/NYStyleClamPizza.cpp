/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "NYStyleClamPizza.h"

NYStyleClamPizza::NYStyleClamPizza()
{
    m_name = "NY Style Clam Pizza";
    m_dough = "Thin Crust Dough";
    m_sauce = "Marinara Sauce";

    m_toppings.push_back("Grated Reggiano Cheese");
    m_toppings.push_back("Fresh Clams from Long Island Sound");

}

NYStyleClamPizza::~NYStyleClamPizza()
{
}
