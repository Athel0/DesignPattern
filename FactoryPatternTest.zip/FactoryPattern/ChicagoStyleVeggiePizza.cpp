/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "ChicagoStyleVeggiePizza.h"

ChicagoStyleVeggiePizza::ChicagoStyleVeggiePizza()
{
    m_name = "Chicago Deep Dish Veggie Pizza";
    m_dough = "Extra Thick Crust Dough";
    m_sauce = "Plum Tomato Sauce";

    m_toppings.push_back("Shredded Mozzarella Cheese");
    m_toppings.push_back("Black Olives");
    m_toppings.push_back("Spinach");
    m_toppings.push_back("Eggplant");
}

ChicagoStyleVeggiePizza::~ChicagoStyleVeggiePizza()
{
}

void ChicagoStyleVeggiePizza::Cut()
{
    cout << "Cutting the pizza into square slices" << endl;
}
