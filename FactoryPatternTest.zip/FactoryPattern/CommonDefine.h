#ifndef COMMONDEFINE_H
#define COMMONDEFINE_H

#define STR_TYPE_CHEESE         "cheese"
#define STR_TYPE_VEGGIE         "veggie"
#define STR_TYPE_CLAM           "clam"
#define STR_TYPE_PEPPERONI      "pepperoni"

#endif // COMMONDEFINE_H
