/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef CHICAGOSTYLEPEPPERONIPIZZA_H
#define CHICAGOSTYLEPEPPERONIPIZZA_H

#include "Pizza.h"

class ChicagoStylePepperoniPizza : public Pizza
{
public:
    ChicagoStylePepperoniPizza();
    virtual ~ChicagoStylePepperoniPizza();

    void Cut();
};

#endif // CHICAGOSTYLEPEPPERONIPIZZA_H
