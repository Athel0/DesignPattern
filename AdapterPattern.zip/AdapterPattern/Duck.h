/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef DUCK_H
#define DUCK_H

class Duck
{
public:
    Duck(){}
    virtual ~Duck(){}

    virtual void Quack()=0;
    virtual void Fly()=0;
};

#endif // DUCK_H
