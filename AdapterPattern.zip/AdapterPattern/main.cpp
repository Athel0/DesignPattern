#include <iostream>
#include "MallardDuck.h"
#include "WildTurkey.h"
#include "TurkeyAdapter.h"

using namespace std;

void testDuck(Duck *duck)
{
    duck->Quack();
    duck->Fly();
}

int main()
{
    MallardDuck *duck = new MallardDuck();

    WildTurkey *turkey = new WildTurkey();
    Duck *turkeyAdapter = new TurkeyAdapter(turkey);

    cout << "The Turkey says..." << endl;
    turkey->Gobble();
    turkey->Fly();

    cout << '\n' << "The Duck says..." << endl;
    testDuck(duck);

    cout << '\n' << "The TurkeyAdapter says..." << endl;
    testDuck(turkeyAdapter);

    return 0;
}
