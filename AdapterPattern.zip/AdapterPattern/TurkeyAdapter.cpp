/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "TurkeyAdapter.h"

TurkeyAdapter::TurkeyAdapter(Turkey *turkey)
    : m_turkey(turkey)
{
}

TurkeyAdapter::~TurkeyAdapter()
{
}

void TurkeyAdapter::Quack()
{
    m_turkey->Gobble();
}

void TurkeyAdapter::Fly()
{
    for(int i = 0; i < 5; i++){
        m_turkey->Fly();
    }
}
