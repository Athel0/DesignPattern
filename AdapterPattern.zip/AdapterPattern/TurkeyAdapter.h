/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef TURKEYADAPTER_H
#define TURKEYADAPTER_H

#include "Duck.h"
#include "Turkey.h"

class TurkeyAdapter : public Duck
{
public:
    TurkeyAdapter(Turkey *turkey);
    virtual ~TurkeyAdapter();

    void Quack();
    void Fly();

private:
    Turkey *m_turkey;
};

#endif // TURKEYADAPTER_H
