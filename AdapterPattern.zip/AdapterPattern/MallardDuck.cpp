/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "MallardDuck.h"

#include <iostream>
using namespace std;

MallardDuck::MallardDuck()
{
}

MallardDuck::~MallardDuck()
{
}

void MallardDuck::Quack()
{
    cout << "Quack" << endl;
}

void MallardDuck::Fly()
{
    cout << "I'm flying" << endl;
}
