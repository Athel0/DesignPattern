/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef TURKEY_H_INCLUDED
#define TURKEY_H_INCLUDED

class Turkey
{
public:
    Turkey(){}
    virtual ~Turkey(){}

    virtual void Gobble()=0;
    virtual void Fly()=0;
};

#endif // TURKEY_H_INCLUDED
