/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#include "WildTurkey.h"

#include <iostream>
using namespace std;

WildTurkey::WildTurkey()
{
}

WildTurkey::~WildTurkey()
{
}

void WildTurkey::Gobble()
{
    cout << "Gobble gobble" << endl;
}

void WildTurkey::Fly()
{
    cout << "I'm flying a short distance" << endl;
}
