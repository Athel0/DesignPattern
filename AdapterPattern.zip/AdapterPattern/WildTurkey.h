/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef WILDTURKEY_H
#define WILDTURKEY_H

#include "Turkey.h"

class WildTurkey : public Turkey
{
public:
    WildTurkey();
    virtual ~WildTurkey();

    void Gobble();
    void Fly();
};

#endif // WILDTURKEY_H
