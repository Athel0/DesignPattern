/*
** Copyright (C) QPSOFT.COM All rights reserved.
*/

#ifndef MALLARDDUCK_H
#define MALLARDDUCK_H

#include "Duck.h"

class MallardDuck : public Duck
{
public:
    MallardDuck();
    virtual ~MallardDuck();

    void Quack();
    void Fly();
};

#endif // MALLARDDUCK_H
